import React from 'react';

function Salas() {
  return <h2>Bienvenido al Lobby de Truco</h2>;
}
export default Salas;